const PRICE_MAP = {
 "CapCut Pro":{"1 Month":45,"3 Months":120,"6 Months":220,"12 Months":400},
 "Spotify Premium":{"1 Month":55,"3 Months":150,"6 Months":280,"12 Months":500},
 "YouTube Premium":{"1 Month":70,"3 Months":190,"6 Months":350,"12 Months":650},
 "Netflix Premium":{"1 Month":85,"3 Months":240,"6 Months":450,"12 Months":850},
 "Telegram Premium":{"1 Month":60,"3 Months":160,"6 Months":300,"12 Months":550},
 "MovieBox Premium":{"1 Month":35,"3 Months":90,"6 Months":170,"12 Months":320},
 "TikTok Followers":{"1,000 Followers":80,"5,000 Followers":350,"10,000 Followers":650},
 "TikTok Likes":{"1,000 Likes":50,"5,000 Likes":220,"10,000 Likes":400},
 "TikTok Views":{"10,000 Views":40,"50,000 Views":170,"100,000 Views":300},
 "TikTok Coins":{"100 Coins":25,"500 Coins":110,"1,000 Coins":210,"5,000 Coins":950}
};
exports.handler=async(event)=>{
 try{
  const secret=process.env.PAYSTACK_SECRET_KEY,ref=event.queryStringParameters?.reference;
  if(!secret||!ref)return {statusCode:400,body:JSON.stringify({paid:false,message:"Missing payment reference"})};
  const r=await fetch("https://api.paystack.co/transaction/verify/"+encodeURIComponent(ref),{headers:{Authorization:"Bearer "+secret}});
  const x=await r.json(),d=x.data,fields=d?.metadata?.custom_fields||[];
  const field=n=>fields.find(f=>f.variable_name===n)?.value;
  const expected=PRICE_MAP[field("product")]?.[field("plan")];
  const paid=!!(x.status&&d&&d.status==="success"&&d.currency==="GHS"&&expected&&Number(d.amount)===Math.round(expected*100));
  return {statusCode:200,headers:{"Content-Type":"application/json"},body:JSON.stringify({paid,message:paid?"Payment confirmed":"Payment is not successful or amount did not match",reference:ref})};
 }catch(e){return {statusCode:500,headers:{"Content-Type":"application/json"},body:JSON.stringify({paid:false,message:"Could not verify payment"})}}
};