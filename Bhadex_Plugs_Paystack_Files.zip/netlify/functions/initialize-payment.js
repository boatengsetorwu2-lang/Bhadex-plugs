const PRICE_MAP = {
 "CapCut Pro":{"1 Month":45,"3 Months":120,"6 Months":220,"12 Months":400},
 "Spotify Premium":{"1 Month":55,"3 Months":150,"6 Months":280,"12 Months":500},
 "YouTube Premium":{"1 Month":70,"3 Months":190,"6 Months":350,"12 Months":650},
 "Netflix Premium":{"1 Month":85,"3 Months":240,"6 Months":450,"12 Months":850},
 "Telegram Premium":{"1 Month":60,"3 Months":160,"6 Months":300,"12 Months":550},
 "MovieBox Premium":{"1 Month":35,"3 Months":90,"6 Months":170,"12 Months":320},
 "TikTok Followers":{"1,000 Followers":80,"5,000 Followers":350,"10,000 Followers":650},
 "TikTok Likes":{"1,000 Likes":50,"5,000 Likes":220,"10,000 Likes":400},
 "TikTok Views":{"10,000 Views":40,"50,000 Views":170,"100,000 Views":300},
 "TikTok Coins":{"100 Coins":25,"500 Coins":110,"1,000 Coins":210,"5,000 Coins":950}
};
exports.handler=async(event)=>{
 if(event.httpMethod!=="POST")return {statusCode:405,body:JSON.stringify({error:"Method not allowed"})};
 try{
  const secret=process.env.PAYSTACK_SECRET_KEY;if(!secret)throw new Error("PAYSTACK_SECRET_KEY is missing in Netlify environment variables.");
  const b=JSON.parse(event.body||"{}");
  const product=String(b.product||""),plan=String(b.plan||""),email=String(b.email||""),name=String(b.name||""),phone=String(b.phone||"");
  const amount=PRICE_MAP[product]?.[plan];
  if(!amount||!email.includes("@")||!name||!phone) return {statusCode:400,body:JSON.stringify({error:"Check your product, plan and customer details."})};
  const siteUrl=process.env.URL||"";
  const resp=await fetch("https://api.paystack.co/transaction/initialize",{method:"POST",headers:{Authorization:`Bearer ${secret}`,"Content-Type":"application/json"},body:JSON.stringify({email,amount:Math.round(amount*100),currency:"GHS",callback_url:siteUrl+"/payment-success",metadata:{custom_fields:[{display_name:"Customer name",variable_name:"customer_name",value:name},{display_name:"WhatsApp",variable_name:"whatsapp",value:phone},{display_name:"Product",variable_name:"product",value:product},{display_name:"Plan",variable_name:"plan",value:plan}]}})});
  const data=await resp.json();if(!resp.ok||!data.status)throw new Error(data.message||"Paystack initialization failed.");
  return {statusCode:200,headers:{"Content-Type":"application/json"},body:JSON.stringify({authorization_url:data.data.authorization_url,reference:data.data.reference})};
 }catch(e){return {statusCode:400,headers:{"Content-Type":"application/json"},body:JSON.stringify({error:e.message||"Payment setup error"})}}
};